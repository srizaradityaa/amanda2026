# Project memory

## Product intent & audience

- Internal government/agency administrative app (Indonesian context, WITA timezone) for managing financial years (TA), officer assignments (penugasan), delegation (Plh./Plt.), and audit trails.
- Roles: Admin, PA/KPA, Bendahara, Verifikator, PPTK, Pengawas/Auditor.
- Implementation proceeds in numbered steps (currently through Step 3); each step is governed by `PAKET_LANGKAH_*.md` specs.

## Brand personality & voice

- Indonesian-language UI and user-facing text.
- Professional, administrative, precise.

## Visual design & UX direction

- Vite + React + Tailwind CSS + Lucide React icons.
- `@/` path alias maps to `src/`.
- Login screen intentionally does NOT show a list of demo accounts (not a product feature).

## Decisions, constraints & rationale

- Business rules are never changed when adding sample data; sample data only fills the existing data-access layer.
- Delegation expiry evaluation runs at app load and login, not only when the Delegation tab is opened. Real 23:59 WITA scheduling waits for backend; flagged accordingly.
- Audit entries for delegation events include `definitive_officer_id`, `delegate_officer_id`, and a status note ("Delegasi Aktif").
- Ended assignments appear in history with date ranges; their SKs remain openable; NON-ACTIVE warning only shows for active assignments.
- Plh./Plt. form offers Bendahara, PPTK, and PA/KPA roles.
- Accounts with only Plh./Plt. delegation can now log in (previously blocked).
- Sample data uses relative dates (via `wita.ts` helper) so "running" vs "expired" statuses stay correct at test time.
- All demo accounts use password `amanda123`.
- `DEMO_DATA.md` at project root holds account table and manual test scenarios.

## Open questions & assumptions

- User wrote "H-48" in the request, but `PAKET_LANGKAH` spec only contains "H-47" — which is correct? (Asked, unresolved.)